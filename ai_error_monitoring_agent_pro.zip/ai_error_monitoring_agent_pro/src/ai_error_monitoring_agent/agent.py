
"""AI Error Monitoring Agent.

This module defines the ErrorMonitoringAgent class, which can be used to train an anomaly detection model on log entries,
detect anomalies in new log entries, and generate remediation suggestions via a language model interface.
"""

from dataclasses import dataclass
from typing import List, Iterable
import logging
import pandas as pd
from sklearn.ensemble import IsolationForest

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


@dataclass
class ErrorMonitoringAgent:
    """A class that encapsulates logic for anomaly detection and suggestion generation."""

    contamination: float = 0.1
    model: IsolationForest | None = None

    def train(self, logs: Iterable[str]) -> None:
        """Train the anomaly detection model on the provided logs.

        Args:
            logs: An iterable of raw log lines.
        """
        logger.info("Starting training on %d log lines", len(list(logs)))
        # Extract features and fit the model
        feature_df = self._extract_features(list(logs))
        self.model = IsolationForest(contamination=self.contamination, random_state=42)
        self.model.fit(feature_df)
        logger.info("Training completed")

    def detect(self, logs: Iterable[str]) -> List[bool]:
        """Detect anomalies in the provided logs.

        Args:
            logs: An iterable of raw log lines.
        Returns:
            A list of booleans indicating whether each log line is anomalous.
        """
        if self.model is None:
            raise ValueError("Model has not been trained.")
        feature_df = self._extract_features(list(logs))
        predictions = self.model.predict(feature_df)
        return [pred == -1 for pred in predictions]

    def generate_suggestion(self, log_line: str) -> str:
        """Generate a remediation suggestion based on the log line.

        This method should be overridden or extended to call an actual language model. The default implementation
        returns a static message.

        Args:
            log_line: The anomalous log line.
        Returns:
            A human-readable suggestion for remediation.
        """
        return (
            f"Potential remediation for '{log_line[:50]}...': Please investigate the issue and restart the service if necessary."
        )

    @staticmethod
    def _extract_features(logs: List[str]) -> pd.DataFrame:
        """Extract simple numerical features from log lines.

        Args:
            logs: A list of log lines.
        Returns:
            A pandas DataFrame with features: the length of each line and a binary flag for errors.
        """
        return pd.DataFrame({
            'length': [len(line) for line in logs],
            'is_error': [1 if ('error' in line.lower() or 'exception' in line.lower()) else 0 for line in logs],
        })

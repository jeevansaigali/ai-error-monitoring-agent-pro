
    """Command-line interface for the AI Error Monitoring Agent.

    This script can be used to run the agent against a log file from the command line. It trains the model on the entire
    log file (assuming it contains mostly normal entries) and then identifies anomalies, printing suggestions for each anomaly.
    """
    import argparse
    import logging
    from .agent import ErrorMonitoringAgent

    logging.basicConfig(level=logging.INFO)

    def read_logs(path: str) -> list[str]:
        with open(path, 'r') as f:
            return [line.strip() for line in f]

    def main() -> None:
        parser = argparse.ArgumentParser(description="Run the AI Error Monitoring Agent on a log file.")
        parser.add_argument('--logs', type=str, required=True, help='Path to the log file to analyze.')
        parser.add_argument('--contamination', type=float, default=0.1, help='Proportion of anomalies expected in the data.')
        args = parser.parse_args()

        agent = ErrorMonitoringAgent(contamination=args.contamination)
        logs = read_logs(args.logs)
        agent.train(logs)
        anomalies = agent.detect(logs)

        for idx, (line, is_anomaly) in enumerate(zip(logs, anomalies)):
            if is_anomaly or 'error' in line.lower():
                suggestion = agent.generate_suggestion(line)
                print(f"Anomaly detected at line {idx + 1}: {line}")
                print(f"Suggestion: {suggestion}
")

    if __name__ == '__main__':
        main()


import pytest
from ai_error_monitoring_agent.agent import ErrorMonitoringAgent

def test_anomaly_detection():
    logs = [
        "INFO Service started",
        "INFO Processing request",
        "ERROR Unexpected null pointer",
        "INFO Request completed",
        "EXCEPTION Database connection lost"
    ]
    agent = ErrorMonitoringAgent(contamination=0.2)
    agent.train(logs)
    anomalies = agent.detect(logs)
    assert len(anomalies) == len(logs)
    # At least the known error lines should be flagged as anomalies or contain error
    error_indices = [i for i, line in enumerate(logs) if 'error' in line.lower() or 'exception' in line.lower()]
    for i in error_indices:
        assert anomalies[i] is True
